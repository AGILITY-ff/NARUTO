module.exports = async (client, player) => {

	client.logger.log(`Player has been destroyed in ${player.guild}`, "log");

}