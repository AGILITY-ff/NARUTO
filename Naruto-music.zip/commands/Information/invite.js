const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
    name: "invite",
    category: "Information",
    aliases: [ "invi", "inv" ],
    description: "invite Naruto Music",
    args: false,
    usage: "",
    permission: [],
    owner: false,
   execute: async (message, args, client, prefix) => {
         
         
    const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://bit.ly/narutoMusic`),
			
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/qJB9npE8HN")
			);

          const mainPage = new MessageEmbed()
            .setAuthor('Naruto Music' , 'https://images-ext-1.discordapp.net/external/2MQp1OLJtUHIIfNLbpsOt0RYOjPQx3eEiV1GxYMSpWo/%3Fsize%3D256/https/cdn.discordapp.com/avatars/898181249800216586/d9cf188727d81dcf54a667d019e0af86.png')
            .setThumbnail('https://images-ext-1.discordapp.net/external/2MQp1OLJtUHIIfNLbpsOt0RYOjPQx3eEiV1GxYMSpWo/%3Fsize%3D256/https/cdn.discordapp.com/avatars/898181249800216586/d9cf188727d81dcf54a667d019e0af86.png')
             .setColor('#303236')
            .addField('invite NarutoMusic', `[Here](https://bit.ly/narutoMusic)`, true)
             .addField("Features","__Naruto Music__ is one of the best high quality music bots out there. We provide all premium features like 24/7 modes and much more at absolutely no cost! ",true)
           message.channel.send({embeds: [mainPage], components: [row]})
    }
}