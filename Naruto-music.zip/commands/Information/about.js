const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");

module.exports = {
    name: "about",
    category: "Information",
    aliases: [ "botinfo" ],
    description: "See description about this project",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
     
    const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=898181249800216586&permissions=2184300800&redirect_uri=https%3A%2F%2Fdiscord.gg%2FqH2RGcGvJK&scope=bot%20applications.commands`),
    
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/qH2RGcGvJK")
			);

      const mainPage = new MessageEmbed()
            .setAuthor('Naruto Music' , 'https://media.discordapp.net/attachments/866294680994709564/898233636627832852/images.jpeg')
            .setThumbnail('https://media.discordapp.net/attachments/866294680994709564/898233636627832852/images.jpeg')
            .setColor('#303236')
        
            .addField('About','We are working very hard on bot to give you the best quality music.',true)
                  .addField(`**Team**`,`[AGILITY 777#2007](https://discord.com/users/724289543213285467)\n[KARTHIK#2960](https://discord.com/users/690170684873375803)\n[Mokshit#0001](https://discord.com/users/675251885904756743)`,true)
        
     
      
            
        return message.channel.send({embeds: [mainPage], components: [row]});
    }
}
