const { MessageEmbed, CommandInteraction, Client, MessageButton, MessageActionRow } = require("discord.js")

module.exports = {
    name: "about",
    description: "Show Pros Music project information",

    /**
     * 
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */

    run: async (client, interaction) => {
        await interaction.deferReply({
            ephemeral: false
        });
   const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot`),
			new MessageButton()
    .setLabel("vote(soon))")
    .setStyle("LINK")
    .setURL("https://top.gg"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/qH2RGcGvJK")
			);

      const mainPage = new MessageEmbed()
            .setAuthor('Naruto Music', 'https://media.discordapp.net/attachments/866294680994709564/898233636627832852/images.jpeg')
            .setThumbnail('https://media.discordapp.net/attachments/866294680994709564/898233636627832852/images.jpeg')
            .setColor('#303236')
            .addField('Main Dev', 'Agility #2007' 
, true) 
            .addField('DEV','Mokshith #0001',true)
            .addField('Organization', 'Naruto MUSIC TEAM', true)
 
 
        await interaction.followUp({embeds: [mainPage], components: [row]});
    }
}
