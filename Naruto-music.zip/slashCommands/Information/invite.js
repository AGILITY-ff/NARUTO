const { MessageEmbed, CommandInteraction, Client, MessageButton, MessageActionRow } = require("discord.js")

module.exports = {
    name: "invite",
    description: "get my invite link",

    /**
     * 
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */

    run: async (client, interaction) => {
        await interaction.deferReply({
            ephemeral: false
        });

           
    const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot`),
			new MessageButton()
    .setLabel("vote")
    .setStyle("LINK")
    .setURL("https://top.gg/bot/892828197522133085"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/qJB9npE8HN")
			);

          const mainPage = new MessageEmbed()
            .setAuthor('Pros Music ', 'https://cdn.discordapp.com/avatars/892828197522133085/afc8320e4359a69c1ed8d5479a21beba.png?size=1024')
            .setThumbnail('https://cdn.discordapp.com/avatars/892828197522133085/afc8320e4359a69c1ed8d5479a21beba.png?size=1024')
             .setColor('#303236')
            .addField('invite Prosmusic', `[Here](https://bit.ly/3B9bpnq)`, true)
           await interaction.followUp({embeds: [mainPage], components: [row]})
    }
}